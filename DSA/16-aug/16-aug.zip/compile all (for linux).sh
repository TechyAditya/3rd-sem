echo 1. Insert element into array
gcc ./prog1.c
./a.out

echo 2. Delete element into array
gcc ./prog2.c
./a.out

echo 3. Address of element
gcc ./prog3.c
./a.out

echo 4. Matrix addition
gcc ./prog4.c
./a.out

echo 5. Matrix multiplication
gcc ./prog5.c
./a.out

echo 6. Menu driven program 
gcc ./prog6.c
./a.out

echo 7. Add and multiply 2 given polynomials
gcc ./prog7.c
./a.out